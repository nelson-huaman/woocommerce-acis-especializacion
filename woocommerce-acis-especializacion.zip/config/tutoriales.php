<div class="tutoriales">
   <div class="tutoriales__h2">Tutoriales</div>
   <div class="tutoriales__texto"><i class="fa fa-hand-o-right" aria-hidden="true"></i> ¿Tienes dudas sobre usar tu membrasía?</div>
   <div class="tutoriales__video">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ChBK8U1foTQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope;
 picture-in-picture; web-share" allowfullscreen></iframe>
   </div>
   <div class="tutoriales__texto"><i class="fa fa-book" aria-hidden="true"></i> ¿Como acceder a la Aula Virtual?</div>
   <div class="tutoriales__video">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/z0g7akAKX5E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope;
 picture-in-picture; web-share" allowfullscreen></iframe>
   </div>
</div>