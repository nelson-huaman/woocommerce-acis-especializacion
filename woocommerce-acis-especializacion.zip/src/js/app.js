import './acordion.js';
import './curso.js';